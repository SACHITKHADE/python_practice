a=12
b=3
add=a+b
sub=a-b
div=a/b
mul=a*b
print("addition",add,"subtraction",sub,"division",div,"multiplication",mul)
