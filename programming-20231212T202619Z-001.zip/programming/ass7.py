i=1
while i<=100:
	print(i)
	i+=1
