a=int(input("enter the no:-"))
b=int(input("enter the no:-"))
add=a+b
sub=a-b
div=a/b
mul=a*b
print("addition",add,"subtraction",sub,"division",div,"multiplication",mul)
