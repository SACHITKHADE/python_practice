def add():
	c=a+b
	print("addition=",c)
def sub():
	c=a-b
	print("subtraction=",c)
def div():
	c=a/b
	print("division=",c)
def mul():
	c=a*b
	print("multiplication=",c)
a=int(input("enter the no:-"))
b=int(input("enter the no:-"))
add()
sub()
div()
mul()
	
