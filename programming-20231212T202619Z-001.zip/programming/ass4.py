a=int(input("enter the no:-"))
b=int(input("enter the no:-"))
if a>b:
	print("a is greater than b")
elif a==b:
	print("both are equal")
else:
	print("b is greater than a")
