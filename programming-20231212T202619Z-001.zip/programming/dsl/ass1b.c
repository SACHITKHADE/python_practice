#include<stdio.h>
int main()
{
int p[10],n,at[10],bt[10],ct[10],tat[10],wt[10],i,j,t=0;
float awt=0,atat=0;
printf("Enter total number of processes(maximum 20):");
scanf("%d",&n);
printf("enter %d process",n);
for(i=0;i<n;i++)
{
scanf("%d",&p[i]);
}
printf("enter %d arrival time:",n);
for(i=0;i<n;i++)
{
scanf("%d",&at[i]);
}
printf("enter %d brust time:",n);
for(i=0;i<n;i++)
{
scanf("%d",&bt[i]);
}
for(i=0;i<n;i++)
{
 for(j=0;j<(n-1);j++)
{
 if (at[j]>at[j+1])
{t=p[j+1];
p[j+1]=p[j];
p[j]=t;
t=at[j+1];
at[j+1]=at[j];
at[j]=t;
t=bt[j+1];
bt[j+1]=bt[j];
bt[j]=t;
}}}
ct[0]=at[0]+bt[0];
for(i=0;i<n;i++)
{
t=0;
if(ct[i-1]<at[i])
     {
        t=at[i]-ct[i-1];
     }
     ct[i]=ct[i-1]+bt[i]+t;
    }
printf("\n P\t A.T\t B.T\t C.T\t TAT\t WT");
for(i=0;i<n;i++)
{
tat[i]=ct[i]-at[i];
wt[i]=tat[i]-bt[i];
}

for(i=0;i<n;i++)
{
printf("\np%d\t %d\t %d\t %d\t %d\t %d",p[i],at[i],bt[i],ct[i],tat[i],wt[i]);
}
return 0;
}
