a=int(input("enter the no:-"))
if a%2==0:
	print("the entered no is even")
else:
	print("the entered no is odd")
