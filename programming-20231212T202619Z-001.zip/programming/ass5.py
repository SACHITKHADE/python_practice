a=int(input("enter the no:-"))
b=int(input("enter the no:-"))
c=int(input("enter the no:-"))
if a>b and a>c:
	print("a is greater than b and c")
elif b>a and b>c:
	print("b is greater than b and c")
else:
	print("c is greater than a and b")
