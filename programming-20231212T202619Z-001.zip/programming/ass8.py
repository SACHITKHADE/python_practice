a=int(input("enter the no:-"))
b=int(input("enter the no:-"))
c=int(input("enter the no:-"))
if a>b and a>c:
	print("a is greater than b and c")
elif b>a and b>c:
	print("b is greater than b and c")
elif a==b>c:
	print("both a and b are equal and greater than c")
elif a==c>b:
	print("both a and c are equal and greater than b")
elif b==c>a:
	print("both b and c are equal and greater than a")
else:
	print("c is greater than a and b")
